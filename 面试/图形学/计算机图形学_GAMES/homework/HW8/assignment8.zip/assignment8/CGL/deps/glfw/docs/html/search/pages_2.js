var searchData=
[
  ['getting_20started',['Getting started',['../quick.html',1,'']]]
];
